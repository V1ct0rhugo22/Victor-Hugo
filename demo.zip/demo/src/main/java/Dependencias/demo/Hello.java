package Dependencias.demo;

import org.springframework.web.bind.annotation.*;

@RestController
public class Hello {

    private Usuario usuario = new Usuario(); // Inicializa um objeto vazio

    @GetMapping("/hello")
    public String getInformations() {
        return "<h1>Hello World</h1>";
    }

    @PutMapping("/hello")
    public String putInformations() {
        return "<h1>I love Victor</h1>";
    }

    @PostMapping("/hello")
    public String postInformations() {
        return "<h1>VLW VINI</h1>";
    }

    @DeleteMapping("/hello")
    public String deleteInformations() {
        return "<h1>MELHOR PROJETO É DE REALIDADE VIRTUAL <3</h1>";
    }

    // Novo endpoint para definir os dados do usuário via POST
    @PostMapping("/usuario")
    public String criarUsuario(@RequestBody Usuario novoUsuario) {
        this.usuario = novoUsuario;
        return "Usuário criado: " + usuario.toString();
    }

    // Novo endpoint para obter os dados do usuário via GET
    @GetMapping("/usuario")
    public Usuario getUsuario() {
        return usuario;
    }
    @PutMapping("/usuario")
    public String atualizarUsuario(@RequestBody Usuario usuarioAtualizado) {
        if (usuario == null) {
            return "Erro: Nenhum usuário encontrado para atualizar.";
        }
        this.usuario = usuarioAtualizado;
        return "Usuário atualizado: " + usuario.toString();
    }
    @DeleteMapping("/usuario")
    public String deletarUsuario() {
        if (usuario == null) {
            return "Erro: Nenhum usuário encontrado para deletar.";
        }
        usuario = null;
        return "Usuário removido com sucesso.";
    }
}